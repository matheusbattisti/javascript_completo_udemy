console.log(null);
console.log(undefined);